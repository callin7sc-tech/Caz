import { world, system } from '@minecraft/server';
// Only initial entity spawns: existing giants are not populated again on world load.
world.afterEvents.entitySpawn.subscribe(({ entity }) => {
  if (entity.typeId !== 'gc:giant') return;
  system.runTimeout(() => {
    try {
      if (!entity.isValid || entity.getDynamicProperty('gc:crew_created')) return;
      const rideable = entity.getComponent('minecraft:rideable');
      if (!rideable) return;
      // Mark before spawning: prevents repeated crew creation.
      entity.setDynamicProperty('gc:crew_created', true);
      for (let i = 0; i < 2; i++) {
        const p = entity.location;
        const rider = entity.dimension.spawnEntity('gc:archer', { x: p.x, y: p.y + 3, z: p.z });
        if (!rideable.addRider(rider)) {
          rider.remove();
          console.warn('[Goblin Caravan] Mount failed: summon a new giant in an open space.');
        }
      }
    } catch (error) { console.warn('[Goblin Caravan] Crew spawn: ' + error); }
  }, 2);
});
